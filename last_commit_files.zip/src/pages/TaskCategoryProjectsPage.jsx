import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { taskCategoryProjectsApi } from "../services/api/taskCategoryProjects";
import { codesApi } from "../services/api/Code";
import codeDetailsApi from "../services/api/CodeDetails";
import { useToast } from "../component/common/ToastContext";
import { Select, MenuItem } from "@mui/material";
import { ActionsMenu } from "../component/common/ResourcePage";
import TaskCategoryProjectModal from "../component/common/TaskCategoryProjectModal";
import DeleteConfirmModal from "../component/common/DeleteConfirmation";
import { ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight } from "lucide-react";

export default function TaskCategoryProjectsPage() {
  const { toast } = useToast();
  const navigate = useNavigate();

  const [projects, setProjects] = useState([]);
  const [selectedProjectId, setSelectedProjectId] = useState("");
  const [loadingProjects, setLoadingProjects] = useState(false);

  const [mappings, setMappings] = useState([]);
  const [loadingMappings, setLoadingMappings] = useState(false);

  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [totalCount, setTotalCount] = useState(0);

  const [actionItem, setActionItem] = useState(null);
  const [actionType, setActionType] = useState("");
  const [actionLoading, setActionLoading] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [editProject, setEditProject] = useState(null); // Dedicated state for updates

  // Load projects for the dropdown
  const loadProjects = async () => {
    setLoadingProjects(true);
    try {
      const allLookups = await codesApi.getAll();
      const projectLookup = allLookups.find((l) => l.lookupCode === "PRJ");
      if (projectLookup) {
        const details = await codeDetailsApi.getAll({ lookupId: projectLookup.id });
        setProjects(details.map((d) => ({ id: d.id, name: d.description || d.newCode })));
      }
    } catch (err) {
      toast("Error fetching projects", "error");
    } finally {
      setLoadingProjects(false);
    }
  };

  // Fetch mappings: selective or global
  const fetchMappings = useCallback(async () => {
    setLoadingMappings(true);
    try {
      const data = await taskCategoryProjectsApi.getAll({
        projectId: selectedProjectId || undefined, // undefined fetches ALL
        skipCount: (page - 1) * pageSize,
        maxResultCount: pageSize,
      });
      setMappings(Array.isArray(data?.items) ? data.items : []);
      setTotalCount(data?.totalCount || 0);
    } catch (err) {
      toast("Failed to load mappings", "error");
    } finally {
      setLoadingMappings(false);
    }
  }, [selectedProjectId, page, pageSize, toast]);

  useEffect(() => { loadProjects(); }, []);
  useEffect(() => { fetchMappings(); }, [fetchMappings]);
  useEffect(() => { setPage(1); }, [selectedProjectId]);

  const handleClear = () => {
    setSelectedProjectId("");
    setPage(1);
  };

  // Using mappings directly as they are now server-side filtered
  const paginatedData = mappings;

  const handleNew = () => {
    setEditProject(null); // Ensure modal is clear
    setModalOpen(true);
  };

  const handleEdit = (row) => {
    setEditProject({ id: row.projectId, name: row.projectDescription || row.description });
    setModalOpen(true);
  };

  const handleDelete = async () => {
    if (!actionItem) return;
    setActionLoading(true);
    try {
      await taskCategoryProjectsApi.delete(actionItem.projectId || actionItem.id);
      toast("Mapping removed !successfully");
      fetchMappings();
    } catch (err) {
      toast("Failed to remove mapping", "error");
    } finally {
      setActionLoading(false);
      setActionItem(null);
      setActionType("");
    }
  };

  const breadcrumb = ["Home", "Management", "Lookups", "Task Category Projects"];

  return (
    <div className="h-full bg-[#f1f5f9] dark:bg-slate-950 overflow-hidden flex flex-col no-scrollbar p-6 transition-all duration-300">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-[10px] text-slate-400 dark:text-slate-400 mb-4 ml-1">
        {breadcrumb.map((b, i) => (
          <span key={i} className="flex items-center gap-2">
            <span
              onClick={() => b === "Home" && navigate("/")}
              className={b === "Home" ? "hover:text-blue-500 cursor-pointer transition-colors" : ""}
            >
              {b}
            </span>
            {i < breadcrumb.length - 1 && <span>/</span>}
          </span>
        ))}
      </nav>

      <div className="flex-1 w-full flex flex-col overflow-hidden">
        <div className="flex-1 bg-white dark:bg-slate-900 h-full w-full border border-slate-100 dark:border-slate-800 rounded-2xl shadow-xl backdrop-blur-sm overflow-hidden flex flex-col transition-all duration-300">

          {/* Header */}
          <div className="px-6 py-6 flex flex-col gap-6 bg-slate-50/50 dark:bg-transparent shrink-0">
            <div className="flex items-center justify-between">
              <h1 className="text-[26px] font-black text-slate-800 dark:text-white tracking-tighter leading-none uppercase">
                Task Category Projects
              </h1>
              <button
                onClick={handleNew}
                className="h-[26px] px-4 btn-flagship rounded-[6px] text-[9.5px] font-black  transition-all active:scale-95 shadow-sm uppercase shadow-blue-500/10"
              >
                New Task Category Project
              </button>
            </div>

            {/* Project Filter */}
            <div className="flex items-end gap-3 w-full max-w-lg">
              <div className="flex flex-col gap-1 flex-1">
                <label className="text-[9.5px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-widest leading-none px-1">
                  Project
                </label>
                <div className="relative">
                  <select
                    value={selectedProjectId}
                    onChange={(e) => setSelectedProjectId(e.target.value)}
                    disabled={loadingProjects}
                    className="w-full appearance-none bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-[11px] font-semibold rounded-lg pl-3 pr-8 py-2 outline-none focus:border-blue-400 transition-all cursor-pointer shadow-sm"
                  >
                    <option value="">Choose An Option</option>
                    {projects.map((p) => (
                      <option key={p.id} value={p.id}>{p.name}</option>
                    ))}
                  </select>
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                      <path d="m6 9 6 6 6-6" />
                    </svg>
                  </div>
                </div>
              </div>
              <button
                onClick={handleClear}
                className="h-[34px] px-5 btn-flagship rounded-lg text-[9.5px] font-black  transition-all active:scale-95 shadow-sm uppercase shrink-0"
              >
                Clear
              </button>
            </div>
          </div>

          {/* Table — no headers, just rows */}
          <div className="flex-1 flex flex-col w-full h-0 overflow-hidden">
            <div className="flex-1 flex flex-col w-full h-0 overflow-hidden relative">
              {loadingMappings ? (
                <div className="flex-1 flex items-center justify-center text-slate-300 text-[11px] font-black uppercase tracking-widest animate-pulse">
                  Loading Data...
                </div>
              ) : mappings.length === 0 ? (
                <div className="flex-1 flex items-center justify-center text-slate-300 text-[11px] font-black uppercase tracking-widest">
                  No Data Found
                </div>
              ) : (
                <div className="flex-1 overflow-y-auto no-scrollbar">
                  <table className="w-full text-[11px] text-slate-800 dark:text-slate-200 border-collapse">
                    <tbody>
                      {paginatedData.map((row, i) => (
                        <tr
                          key={row.projectId || i}
                          className="group transition-colors hover:bg-pink-50 dark:hover:bg-[#ec4899]/10"
                        >
                          {/* Project name — NOW FIRST COLUMN */}
                          <td className="px-6 py-3 font-semibold text-slate-700 dark:text-slate-300 text-[12px]">
                            {row.projectDescription || row.description || ""}
                          </td>
                          {/* Task Category — NOW SECOND COLUMN */}
                          <td style={{ width: 250, minWidth: 250 }} className="px-2 py-3 font-semibold text-slate-700 dark:text-slate-300 text-[12px]">
                            {row.taskCategoryDescription || ""}
                          </td>
                          {/* Actions split button */}
                          <td className="px-6 py-3 text-right">
                            <ActionsMenu
                              onEdit={() => handleEdit(row)}
                              onDelete={() => {
                                setActionItem(row);
                                setActionType("delete");
                              }}
                            />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          {/* Pagination Footer */}
          <div className="px-6 py-4 bg-slate-50/80 dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between shrink-0 transition-colors">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2.5">
                <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 dark:text-slate-500">Page Size:</span>
                <select
                  value={pageSize}
                  onChange={(e) => { setPageSize(Number(e.target.value)); setPage(1); }}
                  className="px-3 h-7 text-[10px] font-black bg-white dark:bg-slate-800 text-pink-600 dark:text-pink-400 border border-slate-200 dark:border-slate-700/50 rounded-lg outline-none transition-all cursor-pointer shadow-sm hover:border-pink-500/50 uppercase tracking-widest"
                >
                  {[5, 10, 25, 50].map((s) => (
                    <option key={s} value={s} className="font-sans">{s}</option>
                  ))}
                </select>
              </div>
              
              <div className="hidden sm:flex items-center gap-2 pl-4 border-l border-slate-200 dark:border-slate-800">
                <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
                  <span className="text-slate-900 dark:text-white tabular-nums">
                    {totalCount > 0 ? (page - 1) * pageSize + 1 : 0}
                  </span>
                  <span className="text-slate-400 dark:text-slate-600 mx-1.5">—</span>
                  <span className="text-slate-900 dark:text-white tabular-nums">
                    {Math.min(page * pageSize, totalCount)}
                  </span>
                  <span className="text-slate-400 dark:text-slate-600 mx-2 lowercase font-bold tracking-normal italic">of</span>
                  <span className="text-slate-900 dark:text-white tabular-nums font-black">
                    {totalCount}
                  </span>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              <div className="flex items-center gap-1 bg-white dark:bg-slate-800/50 p-1 border border-slate-200 dark:border-slate-700/50 rounded-xl shadow-sm">
                <button
                  onClick={() => setPage(1)}
                  disabled={page === 1 || loadingMappings}
                  className="w-7 h-7 flex items-center justify-center rounded-lg text-slate-400 hover:text-pink-600 hover:bg-pink-50 dark:hover:bg-pink-500/5 disabled:opacity-30 disabled:hover:bg-transparent transition-all"
                  title="First Page"
                >
                  <ChevronsLeft size={14} strokeWidth={2.5} />
                </button>
                <button
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                  disabled={page === 1 || loadingMappings}
                  className="w-7 h-7 flex items-center justify-center rounded-lg text-slate-400 hover:text-pink-600 hover:bg-pink-50 dark:hover:bg-pink-500/5 disabled:opacity-30 disabled:hover:bg-transparent transition-all"
                  title="Previous Page"
                >
                  <ChevronLeft size={14} strokeWidth={2.5} />
                </button>
                
                <div className="h-6 w-px bg-slate-100 dark:bg-slate-700/50 mx-1"></div>
                
                <div className="px-3 flex items-center gap-2 py-1">
                  <span className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">Page</span>
                  <div className="flex items-center gap-1.5 min-w-[40px] justify-center">
                    <span className="text-[11px] font-black text-pink-600 dark:text-pink-400 tabular-nums leading-none">{page}</span>
                    <span className="text-[10px] font-black text-slate-300 dark:text-slate-600">/</span>
                    <span className="text-[10px] font-black text-slate-500 dark:text-slate-400 tabular-nums leading-none">{Math.ceil(totalCount / pageSize) || 1}</span>
                  </div>
                </div>

                <div className="h-6 w-px bg-slate-100 dark:bg-slate-700/50 mx-1"></div>

                <button
                  onClick={() => setPage((p) => p + 1)}
                  disabled={page >= Math.ceil(totalCount / pageSize) || loadingMappings}
                  className="w-7 h-7 flex items-center justify-center rounded-lg text-slate-400 hover:text-pink-600 hover:bg-pink-50 dark:hover:bg-pink-500/5 disabled:opacity-30 disabled:hover:bg-transparent transition-all"
                  title="Next Page"
                >
                  <ChevronRight size={14} strokeWidth={2.5} />
                </button>
                <button
                  onClick={() => setPage(Math.ceil(totalCount / pageSize))}
                  disabled={page >= Math.ceil(totalCount / pageSize) || loadingMappings}
                  className="w-7 h-7 flex items-center justify-center rounded-lg text-slate-400 hover:text-pink-600 hover:bg-pink-50 dark:hover:bg-pink-500/5 disabled:opacity-30 disabled:hover:bg-transparent transition-all"
                  title="Last Page"
                >
                  <ChevronsRight size={14} strokeWidth={2.5} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

      <TaskCategoryProjectModal
        open={modalOpen}
        onClose={() => {
          setModalOpen(false);
          setEditProject(null);
        }}
        onSave={() => {
          fetchMappings();
          setEditProject(null);
        }}
        preSelectedProject={editProject}
      />

      {actionType === "delete" && (
        <DeleteConfirmModal
          open={true}
          item={actionItem}
          loading={actionLoading}
          title="Confirm Deleting"
          confirmText="Delete"
          onClose={() => { setActionItem(null); setActionType(""); }}
          onConfirm={handleDelete}
        />
      )}

      <style>{`
        body { overflow: hidden !important; }
        .no-scrollbar::-webkit-scrollbar { display: none !important; }
        .no-scrollbar { -ms-overflow-style: none !important; scrollbar-width: none !important; }
        ::-webkit-scrollbar { display: none !important; }
        * { -ms-overflow-style: none !important; scrollbar-width: none !important; }
      `}</style>
    </div>
  );
}



